module Coyote
	ROOT_PATH = Dir.pwd
end