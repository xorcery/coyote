module Coyote
	def self.say_hello
		puts 'herrro'
	end
end