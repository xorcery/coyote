module Coyote
	VERSION = "0.1.0"
	ROOT_PATH = Dir.pwd
end