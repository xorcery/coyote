module Coyote
  class Builder

		def initialize
			puts "Builder initialize in #{Coyote::ROOT_PATH}"
		end
  end
end