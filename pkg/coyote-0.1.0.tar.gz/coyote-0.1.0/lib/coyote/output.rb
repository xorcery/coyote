module Coyote
  class Output
		
		attr_accessor :output
		
		def initialize 
			@output = ""
		end

		def append(filename)

			File.open(filename, 'r') do |file|
				@output += file.read
       	@output += "\n\n\n\n\n\n\n\n\n"
			end
		end
		

		def save(filename)
			File.open(filename, 'w+') {|f| f.write(@output) }
		end
				
	end
end
			
		
