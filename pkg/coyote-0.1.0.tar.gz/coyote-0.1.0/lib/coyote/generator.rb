module Coyote
  class Generator

		def initialize
		end
  end
end